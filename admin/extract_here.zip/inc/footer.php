 <!-- footer -->
 <footer class="footer"> 
 	&copy;  <span>NACEST, ELEARNING SYSTEM</span> 
 	<script> 
 		var r=new Date();
 		document.write(r.getFullYear());
 	</script> &nbsp; - All Rights Reserved.
 </footer>
